package com.tcs.assessment.Model.dto;

public class CustomerResponse {
}
