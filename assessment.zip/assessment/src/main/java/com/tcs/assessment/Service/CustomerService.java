package com.tcs.assessment.Service;

public interface CustomerService {
}
